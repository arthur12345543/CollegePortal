//= require ckeditor/filebrowser/javascripts/jquery.min.js
//= require ckeditor/filebrowser/javascripts/jquery.tmpl.min.js
//= require ckeditor/filebrowser/javascripts/fileuploader.js
//= require ckeditor/filebrowser/javascripts/rails.js
//= require ckeditor/filebrowser/javascripts/application.js
;